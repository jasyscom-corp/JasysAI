export { default as CONFIG } from './app.config.js';
export { ConfigService } from './config.service.js';