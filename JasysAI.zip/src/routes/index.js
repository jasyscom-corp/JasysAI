export { setupRoutes } from './router.js';
export { authRoutes } from './auth.routes.js';
export { adminRoutes } from './admin.routes.js';
export { userRoutes } from './user.routes.js';
export { apiRoutes } from './api.routes.js';