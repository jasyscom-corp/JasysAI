import { CONFIG } from '../config/index.js';
import { LOGO_SVG } from '../utils/assets.js';

export const UserApp = (user) => `
<!DOCTYPE html><html lang="en" class="dark"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-[#020617] text-slate-200 min-h-screen p-8">
  <div class="max-w-6xl mx-auto">
    <div class="flex justify-between items-center mb-16">
      <div class="flex items-center gap-3 font-bold text-2xl text-white">${LOGO_SVG} ${CONFIG.site_name} Dashboard</div>
      <button onclick="logout()" class="text-red-500 text-sm hover:underline">Logout</button>
    </div>

    <!-- Tabs -->
    <div class="flex gap-1 mb-8">
      <button onclick="showTab('overview')" id="tab-overview" class="px-6 py-3 rounded-xl font-bold bg-brand text-white">Overview</button>
      <button onclick="showTab('packages')" id="tab-packages" class="px-6 py-3 rounded-xl font-bold bg-slate-800 text-slate-400 hover:bg-slate-700">Packages</button>
      <button onclick="showTab('history')" id="tab-history" class="px-6 py-3 rounded-xl font-bold bg-slate-800 text-slate-400 hover:bg-slate-700">Chat History</button>
      <button onclick="showTab('keys')" id="tab-keys" class="px-6 py-3 rounded-xl font-bold bg-slate-800 text-slate-400 hover:bg-slate-700">API Keys</button>
      <button onclick="showTab('account')" id="tab-account" class="px-6 py-3 rounded-xl font-bold bg-slate-800 text-slate-400 hover:bg-slate-700">Account</button>
    </div>

    <!-- Packages Tab -->
    <div id="content-packages" class="tab-content hidden">
      <div class="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem]">
        <h2 class="text-2xl font-bold text-white mb-6">Unlock Premium Models</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6" id="packagesList">
          <!-- Loaded via JS -->
        </div>
      </div>
    </div>

    <!-- Overview Tab -->
    <div id="content-overview" class="tab-content">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div class="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
          <div class="absolute top-0 right-0 p-10 text-brand opacity-10 group-hover:opacity-20 transition">${LOGO_SVG}</div>
          <div class="text-slate-500 text-sm mb-2 uppercase tracking-widest font-bold">Total Credits</div>
          <div class="text-5xl font-black text-white">Rp ${user.credits.toLocaleString()}</div>
          <div class="text-sm text-slate-400 mt-2">Total Used: Rp ${user.total_used?.toLocaleString() || 0}</div>
        </div>
        <div class="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem]">
          <div class="text-slate-500 text-sm mb-4 uppercase tracking-widest font-bold">API Base URL (Cursor/IDE)</div>
          <code class="block bg-black/50 p-4 rounded-2xl text-brand text-xs break-all border border-brand/20">${CONFIG.site_url}/v1</code>
        </div>
      </div>
      <div class="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem]">
        <h2 class="text-2xl font-bold text-white mb-6">Usage Metrics</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div class="text-center">
            <div class="text-3xl font-black text-blue-400">${Object.keys(user.usage_daily || {}).length}</div>
            <div class="text-sm text-slate-500">Active Days</div>
          </div>
          <div class="text-center">
            <div class="text-3xl font-black text-green-400">${user.api_keys?.length || 0}</div>
            <div class="text-sm text-slate-500">API Keys</div>
          </div>
          <div class="text-center">
            <div class="text-3xl font-black text-purple-400">${user.unlocked_models?.length || 0}</div>
            <div class="text-sm text-slate-500">Unlocked Models</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Chat History Tab -->
    <div id="content-history" class="tab-content hidden">
      <div class="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem]">
        <div class="flex justify-between items-center mb-10">
          <h2 class="text-2xl font-bold text-white">Chat History</h2>
          <a href="/chat" class="bg-brand px-6 py-3 rounded-full font-bold shadow-lg shadow-blue-500/20 hover:scale-105 transition">Start New Chat</a>
        </div>
        <div id="chatHistoryList" class="space-y-4">
          <!-- Loaded via JS -->
        </div>
      </div>
    </div>

    <!-- API Keys Tab -->
    <div id="content-keys" class="tab-content hidden">
      <div class="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem]">
        <div class="flex justify-between items-center mb-10">
          <h2 class="text-2xl font-bold text-white">My API Keys</h2>
          <button onclick="createKey()" class="bg-brand px-6 py-3 rounded-full font-bold shadow-lg shadow-blue-500/20 hover:scale-105 transition">Create New Key</button>
        </div>
        <div class="space-y-4">
          ${user.api_keys?.map(k => `
            <div class="bg-dark p-6 rounded-3xl border border-slate-800 flex justify-between items-center hover:border-slate-700 transition">
              <div><div class="font-bold text-white text-lg">${k.name}</div><div class="text-xs text-slate-500">${new Date(k.created).toLocaleDateString()}</div></div>
              <div class="flex gap-2">
                <code class="bg-black/50 px-4 py-2 rounded-xl text-blue-400 text-sm border border-slate-800">${k.key}</code>
                <button onclick="deleteKey('${k.key}')" class="text-red-400 hover:text-red-300 px-3 py-1">×</button>
              </div>
            </div>
          `).join('') || '<div class="text-slate-500 text-center py-8">No API keys yet</div>'}
        </div>
      </div>
    </div>

    <!-- Account Tab -->
    <div id="content-account" class="tab-content hidden">
      <div class="bg-slate-900 border border-slate-800 p-10 rounded-[2.5rem]">
        <h2 class="text-2xl font-bold text-white mb-6">Account Settings</h2>
        <div class="space-y-6">
          <div>
            <label class="block text-sm font-bold text-slate-400 mb-2">Name</label>
            <input id="accountName" class="w-full bg-dark border border-slate-800 p-4 rounded-2xl text-white" value="${user.name}">
          </div>
          <div>
            <label class="block text-sm font-bold text-slate-400 mb-2">Email</label>
            <input id="accountEmail" class="w-full bg-dark border border-slate-800 p-4 rounded-2xl text-white" value="${user.email}" disabled>
          </div>
          <div>
            <label class="block text-sm font-bold text-slate-400 mb-2">Change Password</label>
            <input id="accountPass" type="password" class="w-full bg-dark border border-slate-800 p-4 rounded-2xl text-white" placeholder="New password (leave empty to keep current)">
          </div>
          <button onclick="updateAccount()" class="bg-brand px-6 py-3 rounded-full font-bold shadow-lg shadow-blue-500/20 hover:scale-105 transition">Update Account</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    function showTab(tab) {
      document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
      document.querySelectorAll('[id^=tab-]').forEach(el => {
        el.classList.remove('bg-brand', 'text-white');
        el.classList.add('bg-slate-800', 'text-slate-400');
      });
      document.getElementById('content-' + tab).classList.remove('hidden');
      document.getElementById('tab-' + tab).classList.add('bg-brand', 'text-white');
      document.getElementById('tab-' + tab).classList.remove('bg-slate-800', 'text-slate-400');

      if (tab === 'history') loadChatHistory();
      if (tab === 'packages') loadPackages();
    }

    async function loadChatHistory() {
      const res = await fetch('/api/user/history', { headers: { 'Authorization': localStorage.getItem('t') } });
      if (res.ok) {
        const history = await res.json();
        const list = document.getElementById('chatHistoryList');
        list.innerHTML = history.map(h => \`
          <div class="bg-dark p-6 rounded-3xl border border-slate-800 hover:border-slate-700 transition cursor-pointer" onclick="location.href='/chat'">
            <div class="font-bold text-white text-lg">\${h.title || 'Untitled Chat'}</div>
            <div class="text-xs text-slate-500">\${new Date(h.date).toLocaleString()}</div>
          </div>
        \`).join('') || '<div class="text-slate-500 text-center py-8">No chat history yet</div>';
      }
    }

    async function createKey() {
      const name = prompt("Key Label:"); if(!name) return;
      const res = await fetch('/api/user/keys', {
        method: 'POST',
        headers: { 'Authorization': localStorage.getItem('t'), 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      });
      if (res.ok) {
        alert('API key created successfully!');
        location.reload();
      } else {
        alert('Failed to create API key');
      }
    }

    async function deleteKey(key) {
      if (!confirm('Delete this API key?')) return;
      const res = await fetch('/api/user/keys', {
        method: 'DELETE',
        headers: { 'Authorization': localStorage.getItem('t'), 'Content-Type': 'application/json' },
        body: JSON.stringify({ key })
      });
      if (res.ok) {
        alert('API key deleted successfully!');
        location.reload();
      } else {
        alert('Failed to delete API key');
      }
    }

    async function loadPackages() {
      const packages = ${JSON.stringify(CONFIG.packages)};
      const unlocked = ${JSON.stringify(user.unlocked_models || [])};
      const list = document.getElementById('packagesList');
      list.innerHTML = packages.map(pkg => {
        const isUnlocked = unlocked.some(m => pkg.unlocks.includes(m));
        return \`
          <div class="bg-dark p-6 rounded-3xl border border-slate-800 \${isUnlocked ? 'border-green-500' : ''}">
            <div class="text-xl font-bold text-white mb-2">\${pkg.name}</div>
            <div class="text-3xl font-black text-brand mb-4">Rp \${pkg.price.toLocaleString()}</div>
            <div class="text-sm text-slate-400 mb-4">
              Unlocks: \${pkg.unlocks.join(', ')}
            </div>
            \${isUnlocked ?
              '<div class="text-green-400 font-bold">✓ Unlocked</div>' :
              \`<button onclick="purchasePackage('\${pkg.id}')" class="w-full bg-brand py-3 rounded-xl font-bold hover:scale-105 transition">Purchase</button>\`
            }
          </div>
        \`;
      }).join('');
    }

    async function purchasePackage(packageId) {
      if (!confirm('Purchase this package?')) return;
      const res = await fetch('/api/user/package/purchase', {
        method: 'POST',
        headers: { 'Authorization': localStorage.getItem('t'), 'Content-Type': 'application/json' },
        body: JSON.stringify({ packageId })
      });
      const data = await res.json();
      if (data.ok) {
        alert('Package purchased successfully!');
        location.reload();
      } else {
        alert(data.err || 'Purchase failed');
      }
    }

    async function updateAccount() {
      const name = document.getElementById('accountName').value;
      const pass = document.getElementById('accountPass').value;
      const res = await fetch('/api/user/account/update', {
        method: 'POST',
        headers: { 'Authorization': localStorage.getItem('t'), 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, pass: pass || undefined })
      });
      if (res.ok) {
        alert('Account updated successfully!');
        location.reload();
      } else {
        alert('Failed to update account');
      }
    }

    function logout() {
      localStorage.clear();
      location.href = '/app';
    }

    // Default to overview
    showTab('overview');
  </script>
</body></html>`;

export const AdminApp = (data) => `
<!DOCTYPE html><html lang="en" class="dark"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-black text-slate-300 p-10">
  <div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-12">
      <h1 class="text-4xl font-black text-white tracking-tighter italic">ADMIN <span class="text-brand">GATEWAY</span></h1>
      <button onclick="logout()" class="text-red-500 text-sm hover:underline">Logout</button>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
      <div class="bg-slate-900 p-8 rounded-3xl border border-slate-800"><div class="text-slate-500 text-xs font-bold mb-1 uppercase tracking-widest">Users</div><div class="text-4xl font-black text-white">${data.userCount}</div></div>
      <div class="bg-slate-900 p-8 rounded-3xl border border-slate-800 col-span-3">
        <div class="text-slate-500 text-xs font-bold mb-3 uppercase tracking-widest">OpenRouter Provider Key</div>
        <div class="flex gap-4">
          <input id="okey" class="flex-1 bg-black border border-slate-800 p-3 rounded-xl text-xs font-mono" value="${data.settings.openrouter_key || ''}">
          <button onclick="saveSet()" class="bg-blue-600 px-10 rounded-xl font-bold hover:bg-blue-500">Save</button>
        </div>
      </div>
    </div>
    <div class="bg-slate-900 rounded-[2rem] border border-slate-800 overflow-hidden shadow-2xl">
      <table class="w-full text-left text-xs font-mono">
        <thead class="bg-slate-800/50 text-slate-500 border-b border-slate-800">
          <tr><th class="p-5">Time</th><th class="p-5">User</th><th class="p-5">Model</th><th class="p-5">Tokens</th><th class="p-5">Profit (IDR)</th></tr>
        </thead>
        <tbody class="divide-y divide-slate-800">
          ${data.logs.map(l => `<tr><td class="p-5 text-slate-500">${l.time.slice(11,19)}</td><td class="p-5 font-bold text-white">${l.email}</td><td class="p-5 text-blue-500">${l.model}</td><td class="p-5">${l.tokens}</td><td class="p-5 text-green-400">Rp ${l.cost.toLocaleString()}</td></tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>
  <script>
    async function saveSet() {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Authorization': localStorage.getItem('adm_t'), 'Content-Type': 'application/json' },
        body: JSON.stringify({ openrouter_key: document.getElementById('okey').value })
      });
      if (res.ok) {
        alert('Settings updated successfully!');
      } else {
        alert('Failed to update settings');
      }
    }

    function logout() {
      localStorage.clear();
      location.href = '/admin';
    }
  </script>
</body></html>`;

// Login/Register Pages
export const LoginPage = () => `
<!DOCTYPE html><html lang="en" class="dark"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-[#010409] text-slate-300 min-h-screen flex items-center justify-center p-6">
  <div class="w-full max-w-md">
    <div class="text-center mb-8">
      <div class="text-3xl font-black text-white mb-2">${CONFIG.site_name}</div>
      <div class="text-slate-500 text-sm">Sign in to your account</div>
    </div>
    
    <div class="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl">
      <form id="loginForm" onsubmit="handleLogin(event)">
        <div class="mb-6">
          <label class="block text-sm font-medium text-slate-400 mb-2">Email</label>
          <input type="email" id="email" required class="w-full bg-slate-800 border border-slate-700 p-4 rounded-xl text-white focus:border-brand focus:outline-none transition" placeholder="your@email.com">
        </div>
        
        <div class="mb-6">
          <label class="block text-sm font-medium text-slate-400 mb-2">Password</label>
          <input type="password" id="password" required class="w-full bg-slate-800 border border-slate-700 p-4 rounded-xl text-white focus:border-brand focus:outline-none transition" placeholder="••••••••">
        </div>
        
        <button type="submit" id="loginBtn" class="w-full bg-brand text-white p-4 rounded-xl font-bold hover:bg-brand/90 transition disabled:opacity-50">
          Sign In
        </button>
        
        <div class="text-center mt-6">
          <span class="text-slate-500 text-sm">Don't have an account? </span>
          <button type="button" onclick="showRegister()" class="text-brand text-sm hover:underline">Sign up</button>
        </div>
      </form>
    </div>
    
    <div class="text-center mt-6">
      <a href="/admin" class="text-slate-500 text-sm hover:text-slate-400 transition">Admin Portal →</a>
    </div>
  </div>

  <script>
    async function handleLogin(event) {
      event.preventDefault();
      const btn = document.getElementById('loginBtn');
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      
      btn.disabled = true;
      btn.textContent = 'Signing in...';
      
      try {
        const response = await fetch('/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, pass: password })
        });
        
        const data = await response.json();
        
        if (data.ok) {
          localStorage.setItem('t', data.token);
          localStorage.setItem('role', data.role);
          location.href = '/app';
        } else {
          alert(data.err || 'Login failed');
        }
      } catch (error) {
        alert('Connection error. Please try again.');
      } finally {
        btn.disabled = false;
        btn.textContent = 'Sign In';
      }
    }
    
    function showRegister() {
      location.reload();
    }
  </script>
</body></html>`;

export const RegisterPage = () => `
<!DOCTYPE html><html lang="en" class="dark"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-[#010409] text-slate-300 min-h-screen flex items-center justify-center p-6">
  <div class="w-full max-w-md">
    <div class="text-center mb-8">
      <div class="text-3xl font-black text-white mb-2">${CONFIG.site_name}</div>
      <div class="text-slate-500 text-sm">Create your account</div>
    </div>
    
    <div class="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl">
      <form id="registerForm" onsubmit="handleRegister(event)">
        <div class="mb-4">
          <label class="block text-sm font-medium text-slate-400 mb-2">Full Name</label>
          <input type="text" id="name" required class="w-full bg-slate-800 border border-slate-700 p-4 rounded-xl text-white focus:border-brand focus:outline-none transition" placeholder="John Doe">
        </div>
        
        <div class="mb-4">
          <label class="block text-sm font-medium text-slate-400 mb-2">Email</label>
          <input type="email" id="email" required class="w-full bg-slate-800 border border-slate-700 p-4 rounded-xl text-white focus:border-brand focus:outline-none transition" placeholder="your@email.com">
        </div>
        
        <div class="mb-6">
          <label class="block text-sm font-medium text-slate-400 mb-2">Password</label>
          <input type="password" id="password" required minlength="6" class="w-full bg-slate-800 border border-slate-700 p-4 rounded-xl text-white focus:border-brand focus:outline-none transition" placeholder="••••••••">
        </div>
        
        <button type="submit" id="registerBtn" class="w-full bg-brand text-white p-4 rounded-xl font-bold hover:bg-brand/90 transition disabled:opacity-50">
          Create Account
        </button>
        
        <div class="text-center mt-6">
          <span class="text-slate-500 text-sm">Already have an account? </span>
          <button type="button" onclick="showLogin()" class="text-brand text-sm hover:underline">Sign in</button>
        </div>
      </form>
    </div>
    
    <div class="text-center mt-6">
      <a href="/admin" class="text-slate-500 text-sm hover:text-slate-400 transition">Admin Portal →</a>
    </div>
  </div>

  <script>
    async function handleRegister(event) {
      event.preventDefault();
      const btn = document.getElementById('registerBtn');
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      
      btn.disabled = true;
      btn.textContent = 'Creating account...';
      
      try {
        const response = await fetch('/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, pass: password })
        });
        
        const data = await response.json();
        
        if (data.ok) {
          alert('Account created successfully! Please sign in.');
          showLogin();
        } else {
          alert(data.err || 'Registration failed');
        }
      } catch (error) {
        alert('Connection error. Please try again.');
      } finally {
        btn.disabled = false;
        btn.textContent = 'Create Account';
      }
    }
    
    function showLogin() {
      location.reload();
    }
  </script>
</body></html>`;

export const AdminLoginPage = () => `
<!DOCTYPE html><html lang="en" class="dark"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-black text-slate-300 min-h-screen flex items-center justify-center p-6">
  <div class="w-full max-w-md">
    <div class="text-center mb-8">
      <div class="text-3xl font-black text-white mb-2">Admin Portal</div>
      <div class="text-slate-500 text-sm">${CONFIG.site_name}</div>
    </div>
    
    <div class="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl">
      <form id="adminLoginForm" onsubmit="handleAdminLogin(event)">
        <div class="mb-6">
          <label class="block text-sm font-medium text-slate-400 mb-2">Username</label>
          <input type="text" id="username" required class="w-full bg-slate-800 border border-slate-700 p-4 rounded-xl text-white focus:border-brand focus:outline-none transition" placeholder="admin">
        </div>
        
        <div class="mb-6">
          <label class="block text-sm font-medium text-slate-400 mb-2">Password</label>
          <input type="password" id="password" required class="w-full bg-slate-800 border border-slate-700 p-4 rounded-xl text-white focus:border-brand focus:outline-none transition" placeholder="••••••••">
        </div>
        
        <button type="submit" id="loginBtn" class="w-full bg-brand text-white p-4 rounded-xl font-bold hover:bg-brand/90 transition disabled:opacity-50">
          Sign In
        </button>
        
        <div class="text-center mt-6">
          <a href="/app" class="text-slate-500 text-sm hover:text-slate-400 transition">← User Portal</a>
        </div>
      </form>
    </div>
  </div>

  <script>
    async function handleAdminLogin(event) {
      event.preventDefault();
      const btn = document.getElementById('loginBtn');
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      
      btn.disabled = true;
      btn.textContent = 'Signing in...';
      
      try {
        const response = await fetch('/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user: username, pass: password })
        });
        
        const data = await response.json();
        
        if (data.ok) {
          localStorage.setItem('adm_t', data.token);
          localStorage.setItem('role', data.role);
          location.href = '/admin';
        } else {
          alert(data.err || 'Login failed');
        }
      } catch (error) {
        alert('Connection error. Please try again.');
      } finally {
        btn.disabled = false;
        btn.textContent = 'Sign In';
      }
    }
  </script>
</body></html>`;